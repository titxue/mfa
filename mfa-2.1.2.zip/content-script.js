(()=>{var{defineProperty:qq,getOwnPropertyNames:Lq,getOwnPropertyDescriptor:Mq}=Object,Uq=Object.prototype.hasOwnProperty;function _q(q){return this[q]}var xq=(q)=>{var J=(Jq??=new WeakMap).get(q),Q;if(J)return J;if(J=qq({},"__esModule",{value:!0}),q&&typeof q==="object"||typeof q==="function"){for(var X of Lq(q))if(!Uq.call(J,X))qq(J,X,{get:_q.bind(q,X),enumerable:!(Q=Mq(q,X))||Q.enumerable})}return Jq.set(q,J),J},Jq;var fq={};var T={autofillInlineMenu:!0,clipboardFallback:!0};class S{static isStorageAvailable(){return typeof chrome<"u"&&chrome.storage&&chrome.storage.sync!==void 0}static async getFromStorage(q,J="sync"){try{if(this.isStorageAvailable())return(await chrome.storage[J].get(q))[q];else{let Q=localStorage.getItem(q);return Q?JSON.parse(Q):void 0}}catch(Q){return}}static async saveToStorage(q,J,Q="sync"){try{if(this.isStorageAvailable())await chrome.storage[Q].set({[q]:J});else localStorage.setItem(q,JSON.stringify(J))}catch(X){}}static async getAccounts(){return await this.getFromStorage("accounts")||[]}static async saveAccounts(q){await this.saveToStorage("accounts",q)}static async getState(){return await this.getFromStorage("state")}static async saveState(q){await this.saveToStorage("state",q)}static async getLanguage(){return await this.getFromStorage("language")||"zh-CN"}static async saveLanguage(q){await this.saveToStorage("language",q)}static async removeLanguage(){try{if(this.isStorageAvailable())await chrome.storage.sync.remove("language");else localStorage.removeItem("language")}catch(q){}}static async getSettings(){let q=await this.getFromStorage("autofillSettings");return{...T,...q}}static async saveSettings(q){await this.saveToStorage("autofillSettings",q)}static async clear(){try{if(this.isStorageAvailable())await chrome.storage.sync.clear();else localStorage.clear()}catch(q){}}}var zq=new Set(["text","tel","number","password"]),Nq=["otp","totp","2fa","mfa","authenticator","verification","verify","securitycode","onetime","onetim","one-time","验证码","动态码","安全码","双重验证","两步验证","一次性密码","驗證碼","動態碼","安全碼","雙重驗證","兩步驗證","一次性密碼","verificacion","autenticacion","vérification","verification","verifizierung","bestätigung","bestaetigung","подтверждени","проверочный","التحقق","認証コード","確認コード","ワンタイム","認証","인증","일회용","보안코드","सत्यापन"],Oq=["login","signin","log in","sign in","verify","continue","submit","登录","登入","验证","继续","确认","提交","iniciarsesion","entrar","connexion","seconnecter","anmelden","einloggen","weiter","войти","продолжить","подтвердить","دخول","متابعة","ログイン","ログインする","次へ","로그인","계속","확인","साइनइन","लॉगइन","जारीरखें"];function h(q){return q.toLowerCase().replace(/[^a-z0-9\u00c0-\u024f\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af\u0600-\u06ff\u0900-\u097f]/g,"")}function Wq(q){if(q instanceof HTMLInputElement&&(q.disabled||q.readOnly))return!1;let J=q.getClientRects();if(J.length===0)return!1;let Q=J[0];return Q.width>0&&Q.height>0}function Bq(q){return[q.name,q.id,q.placeholder,q.getAttribute("aria-label"),q.getAttribute("autocomplete"),q.className,q.getAttribute("inputmode")].filter(Boolean).join(" ")}function Fq(q){let J=[];if(q.labels){for(let X of q.labels)if(X.textContent)J.push(X.textContent)}let Q=q.getAttribute("aria-labelledby");if(Q)for(let X of Q.split(/\s+/)){let $=document.getElementById(X);if($&&$.textContent)J.push($.textContent)}return J.join(" ")}function Qq(q){let J=h(q);return Nq.some((Q)=>J.includes(Q))}function Aq(q){let J=q.parentElement;for(let Q=0;Q<4&&J;Q++){if(!(J instanceof HTMLElement))break;let X=J.querySelectorAll("input, button");for(let $ of X){if($===q)continue;if($ instanceof HTMLInputElement&&$.type==="password")return!0;if($.tagName==="BUTTON"){let z=h($.textContent||$.getAttribute("aria-label")||"");if(z&&Oq.some((W)=>z.includes(W)))return!0}}J=J.parentElement}return!1}function Zq(q){if(!zq.has(q.type))return 0;if(!Wq(q))return 0;let J=(q.getAttribute("autocomplete")||"").toLowerCase();if(J==="one-time-code")return 100;let Q=Bq(q),X=Fq(q),$=q.maxLength,z=(q.getAttribute("inputmode")||"").toLowerCase(),W=0;if(Qq(Q))W=Math.max(W,80);if(Qq(X))W=Math.max(W,70);if((z==="numeric"||z==="tel")&&$>=4&&$<=8)W=Math.max(W,55);if(h(Q).includes("code")&&$>=4&&$<=8&&z==="numeric")W=Math.max(W,60);if(W<50&&q.type!=="password"&&Aq(q))W=Math.max(W,45);if(J==="off"&&W<60)W=Math.max(0,W-20);return W}function p(q){return Zq(q)>=40}function m(){let q=Array.from(document.querySelectorAll("input")),J=null,Q=0;for(let X of q){let $=Zq(X);if($>Q)Q=$,J=X}return Q>=40?J:null}function f(q){if(!zq.has(q.type))return!1;if(!Wq(q))return!1;return q.maxLength===1||q.getAttribute("size")==="1"}function vq(q){return q.sort((J,Q)=>J.compareDocumentPosition(Q)&Node.DOCUMENT_POSITION_FOLLOWING?-1:1)}function E(q){let J=Array.from(document.querySelectorAll("input")).filter(f),Q=q.parentElement;for(let X=0;X<3&&Q;X++){let $=J.filter((z)=>z.parentElement===Q||z.parentElement?.parentElement===Q);if($.length>=4&&$.length<=8)return vq($);Q=Q.parentElement}return null}function d(){let q=Array.from(document.querySelectorAll("input"));for(let J of q)if(f(J)){let Q=E(J);if(Q)return Q}return null}function Vq(q,J){let Q=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"value");if(Q&&Q.set)Q.set.call(q,J);else q.value=J}function Yq(q){q.dispatchEvent(new Event("input",{bubbles:!0,cancelable:!0})),q.dispatchEvent(new Event("change",{bubbles:!0,cancelable:!0}))}function Kq(q){q.dataset.mfaFilled="true"}function $q(q,J){return Vq(J,q),Yq(J),J.focus(),Kq(J),{status:"filled",mode:"single"}}function Xq(q,J){let Q=q.replace(/\D/g,"");return J.forEach(($,z)=>{if(z<Q.length)Vq($,Q[z]),Yq($),Kq($)}),(J.find(($)=>$.value==="")||J[J.length-1]).focus(),{status:"filled",mode:"segmented"}}function l(q,J){try{if(J){let $=E(J);if($)return Xq(q,$);if(p(J))return $q(q,J)}let Q=d();if(Q)return Xq(q,Q);let X=m();if(X)return $q(q,X);return{status:"no-field",mode:"single"}}catch{return{status:"error",mode:"single"}}}function r(q,J){return(q<<J|q>>>32-J)>>>0}function u(q){let J=q.length,Q=J+1+(56-(J+1)%64+64)%64+8,X=new Uint8Array(Q);X.set(q),X[J]=128;let $=new DataView(X.buffer);$.setUint32(Q-8,0,!1),$.setUint32(Q-4,J*8,!1);let z=1732584193,W=4023233417,Z=2562383102,V=271733878,K=3285377520,Y=new Uint32Array(80);for(let M=0;M<Q;M+=64){for(let j=0;j<16;j++)Y[j]=$.getUint32(M+j*4,!1);for(let j=16;j<80;j++)Y[j]=r(Y[j-3]^Y[j-8]^Y[j-14]^Y[j-16],1);let N=z,G=W,U=Z,O=V,g=K;for(let j=0;j<80;j++){let y,H;if(j<20)y=G&U|~G&O,H=1518500249;else if(j<40)y=G^U^O,H=1859775393;else if(j<60)y=G&U|G&O|U&O,H=2400959708;else y=G^U^O,H=3395469782;let Cq=r(N,5)+y+g+H+Y[j]|0;g=O,O=U,U=r(G,30),G=N,N=Cq}z=z+N|0,W=W+G|0,Z=Z+U|0,V=V+O|0,K=K+g|0}let P=new Uint8Array(20),L=new DataView(P.buffer);return L.setUint32(0,z,!1),L.setUint32(4,W,!1),L.setUint32(8,Z,!1),L.setUint32(12,V,!1),L.setUint32(16,K,!1),P}function Pq(q,J){let Q=q;if(Q.length>64)Q=u(Q);let X=new Uint8Array(64).fill(54),$=new Uint8Array(64).fill(92);for(let V=0;V<Q.length;V++)X[V]^=Q[V],$[V]^=Q[V];let z=new Uint8Array(X.length+J.length);z.set(X),z.set(J,X.length);let W=u(z),Z=new Uint8Array($.length+W.length);return Z.set($),Z.set(W,$.length),u(Z)}class A{static BASE32_CHARS="ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";static base32Decode(q){let J="",Q=q.toUpperCase().replace(/\s/g,"");for(let $=0;$<Q.length;$++){let z=this.BASE32_CHARS.indexOf(Q[$]);if(z===-1)throw Error("Invalid base32 character");J+=z.toString(2).padStart(5,"0")}let X=new Uint8Array(Math.floor(J.length/8));for(let $=0;$<X.length;$++)X[$]=parseInt(J.substr($*8,8),2);return X}static async generateTOTP(q,J=30){let Q=this.base32Decode(q),X=Math.floor(Date.now()/1000/J),$=new ArrayBuffer(8);new DataView($).setBigUint64(0,BigInt(X),!1);let W;if(typeof crypto<"u"&&crypto.subtle){let K=await crypto.subtle.importKey("raw",Q,{name:"HMAC",hash:"SHA-1"},!1,["sign"]),Y=await crypto.subtle.sign("HMAC",K,$);W=new Uint8Array(Y)}else W=Pq(Q,new Uint8Array($));let Z=W[19]&15;return(((W[Z]&127)<<24|(W[Z+1]&255)<<16|(W[Z+2]&255)<<8|W[Z+3]&255)%1e6).toString().padStart(6,"0")}static getRemainingSeconds(q=30){return q-Math.floor(Date.now()/1000)%q}static formatCode(q){return`${q.slice(0,3)} ${q.slice(3)}`}}var c=24,Dq=6,o=`
.mfa-button {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 24px;
  height: 24px;
  padding: 0;
  border-radius: 9999px;
  background: hsl(0 0% 100%);
  border: 1px solid hsl(240 5.9% 90%);
  color: hsl(240 5.9% 10%);
  cursor: pointer;
  box-shadow: 0 1px 2px rgb(0 0 0 / 0.1);
  transition: background-color 150ms;
  font-family: inherit;
}
.mfa-button:hover {
  background: hsl(240 4.8% 95.9%);
}
.mfa-button svg {
  display: block;
}
.mfa-menu {
  box-sizing: border-box;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'Noto Sans', sans-serif;
  background: hsl(0 0% 100%);
  color: hsl(240 10% 3.9%);
  border: 1px solid hsl(240 5.9% 90%);
  border-radius: 0.5rem;
  box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
  min-width: 220px;
  max-width: 320px;
  max-height: 280px;
  overflow-y: auto;
  padding: 4px;
  animation: mfa-menu-in 120ms ease-out;
}
@keyframes mfa-menu-in {
  from { opacity: 0; transform: scale(0.95); }
  to { opacity: 1; transform: scale(1); }
}
.mfa-menu::-webkit-scrollbar { display: none; }
.mfa-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 8px;
  border-radius: 4px;
  cursor: pointer;
  user-select: none;
  transition: background-color 150ms;
}
.mfa-item:hover,
.mfa-item:focus-visible {
  background: hsl(240 4.8% 95.9%);
  outline: none;
}
.mfa-item-icon {
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 26px;
  height: 26px;
  border-radius: 9999px;
  background: hsl(240 4.8% 95.9%);
  color: hsl(240 3.8% 46.1%);
  transition: color 150ms;
}
.mfa-item:hover .mfa-item-icon {
  color: hsl(240 5.9% 10%);
}
.mfa-item-main {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.mfa-item-name {
  font-size: 14px;
  font-weight: 500;
  color: hsl(240 10% 3.9%);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.mfa-item-code {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, 'Liberation Mono', monospace;
  font-size: 14px;
  font-weight: 700;
  letter-spacing: 0.05em;
  color: hsl(240 5.9% 10%);
}
.mfa-item-fill {
  flex-shrink: 0;
  padding: 3px 10px;
  border-radius: 4px;
  border: 1px solid hsl(240 5.9% 90%);
  background: hsl(0 0% 100%);
  color: hsl(240 5.9% 10%);
  font-size: 12px;
  font-weight: 500;
  font-family: inherit;
  cursor: pointer;
  transition: background-color 150ms;
}
.mfa-item:hover .mfa-item-fill {
  background: hsl(240 5.9% 10%);
  color: hsl(0 0% 98%);
  border-color: transparent;
}
.mfa-item-fill:focus-visible {
  outline: none;
  background: hsl(240 5.9% 10%);
  color: hsl(0 0% 98%);
  border-color: transparent;
}
.mfa-feedback-badge {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 20px;
  height: 20px;
  border-radius: 9999px;
  background: hsl(142 76% 36%);
  color: #fff;
  font-size: 12px;
  font-weight: 700;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  box-shadow: 0 1px 2px rgb(0 0 0 / 0.15);
  animation: mfa-feedback-in 150ms ease-out;
}
@keyframes mfa-feedback-in {
  from { opacity: 0; transform: scale(0.6); }
  to { opacity: 1; transform: scale(1); }
}
.mfa-empty {
  padding: 6px 8px;
  font-size: 14px;
  color: hsl(240 3.8% 46.1%);
}
`,jq='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="7.5" cy="15.5" r="5.5"/><path d="m21 2-9.6 9.6"/><path d="m15.5 7.5 3 3L22 7l-3-3"/></svg>',wq=new Set(["com","net","org","io","co","cn","jp","de","ru","fr","es","br","in","kr","tw","hk","uk","au","ca","me","app","dev","site","top","xyz","online","store","shop","gov","edu","info","biz","cloud","work","live"]);function yq(q){return q.toLowerCase().replace(/[^a-z0-9\u00c0-\u024f\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af\u0600-\u06ff\u0900-\u097f]/g,"")}function a(q,J){let Q=J.toLowerCase();if(q.website)try{let z=new URL(q.website).hostname.toLowerCase();if(Q===z||Q.endsWith("."+z)||z.endsWith("."+Q))return!0}catch{}let X=yq(q.name);if(!X)return!1;return Q.split(".").filter((z)=>z&&!wq.has(z)).some((z)=>{if(z.length>=3&&X.includes(z))return!0;if(X.length>=4&&z.includes(X))return!0;return!1})}function n(q,J){return q.filter((Q)=>a(Q,J))}var _=null,I=null,C=null,v=null,D=null,B=null,F=null,b=null,w=null,Gq=[],k=null,R=null;function t(q){if(k!==null)window.clearTimeout(k),k=null;if(R&&R.parentNode)R.parentNode.removeChild(R),R=null;let J=q.ownerDocument;q.style.outline="2px solid hsl(142 76% 36%)",q.style.outlineOffset="1px",R=J.createElement("div"),R.style.cssText="all: initial; position: fixed; z-index: 2147483647;";let Q=R.attachShadow({mode:"closed"}),X=J.createElement("style");X.textContent=o,Q.appendChild(X);let $=J.createElement("div");$.className="mfa-feedback-badge",$.textContent="✓",Q.appendChild($);let z=q.getBoundingClientRect(),W=Math.min(Math.max(z.right+8,4),Math.max(4,window.innerWidth-28)),Z=z.top+Math.max(0,(z.height-20)/2);R.style.left=Math.round(W)+"px",R.style.top=Math.round(Z)+"px",J.documentElement.appendChild(R),k=window.setTimeout(()=>{if(q.style.outline="",q.style.outlineOffset="",R&&R.parentNode)R.parentNode.removeChild(R);R=null,k=null},1200)}function x(){if(w!==null)window.clearTimeout(w),w=null;for(let q of Gq.splice(0))try{q()}catch{}if(F!==null)window.clearInterval(F),F=null;if(_=null,I=null,v=null,B=null,D&&D.parentNode)D.parentNode.removeChild(D);if(D=null,C&&C.parentNode)C.parentNode.removeChild(C);C=null}function i(){if(!C||!_)return;let q=_.getBoundingClientRect();if(q.width<=0||q.height<=0){x();return}let J=Math.min(Math.max(q.right-c-4,4),Math.max(4,window.innerWidth-c-4)),Q=q.top+Math.max(0,(q.height-c)/2);C.style.left=Math.round(J)+"px",C.style.top=Math.round(Q)+"px"}function Hq(q){if(!D||!C)return;let J=C.getBoundingClientRect(),Q=Math.min(Math.max(q.offsetWidth,220),320),X=q.offsetHeight,$=window.innerWidth,z=window.innerHeight,W=J.bottom+Dq;if(W+X>z-8)W=Math.max(8,J.top-Dq-X);let Z=Math.min(Math.max(J.left,8),Math.max(8,$-8-Q));D.style.left=Math.round(Z)+"px",D.style.top=Math.round(W)+"px"}function kq(q,J){let Q=q.ownerDocument;q.innerHTML="";let X=[...J.accounts].sort((Z,V)=>Number(a(V,window.location.hostname))-Number(a(Z,window.location.hostname)));if(X.length===0){let Z=Q.createElement("div");return Z.className="mfa-empty",Z.textContent=J.strings.noAccounts,q.appendChild(Z),()=>{}}let $=new Map;for(let Z of X){let V=Q.createElement("div");V.className="mfa-item",V.setAttribute("role","button"),V.tabIndex=0;let K=Q.createElement("span");K.className="mfa-item-icon",K.innerHTML=jq;let Y=Q.createElement("div");Y.className="mfa-item-main";let P=Q.createElement("div");P.className="mfa-item-name",P.textContent=Z.name;let L=Q.createElement("div");L.className="mfa-item-code",L.textContent="······",$.set(Z,L),Y.appendChild(P),Y.appendChild(L);let M=Q.createElement("button");M.type="button",M.className="mfa-item-fill",M.textContent=J.strings.fill,V.appendChild(K),V.appendChild(Y),V.appendChild(M);let N=()=>{let G=J.onFill;x(),A.generateTOTP(Z.secret).then((U)=>G(Z,U)).catch(()=>{})};V.addEventListener("click",N),M.addEventListener("click",(G)=>{G.stopPropagation(),N()}),V.addEventListener("keydown",(G)=>{if(G.key==="Enter"||G.key===" ")G.preventDefault(),N()}),q.appendChild(V)}let z=Array.from(q.querySelectorAll(".mfa-item"));if(z.length>0)z[0].focus();q.addEventListener("keydown",(Z)=>{let V=Array.from(q.querySelectorAll(".mfa-item")),K=V.indexOf(Z.target);if(Z.key==="ArrowDown")Z.preventDefault(),V[Math.min(V.length-1,K+1)]?.focus();else if(Z.key==="ArrowUp")Z.preventDefault(),V[Math.max(0,K-1)]?.focus();else if(Z.key==="Home")Z.preventDefault(),V[0]?.focus();else if(Z.key==="End")Z.preventDefault(),V[V.length-1]?.focus()});let W=()=>{for(let[Z,V]of $)A.generateTOTP(Z.secret).then((K)=>{if(V.isConnected)V.textContent=A.formatCode(K)}).catch(()=>{})};return W(),W}function Iq(){if(!_||!I||D)return;let q=_.ownerDocument;D=q.createElement("div"),D.style.cssText="all: initial; position: fixed; z-index: 2147483647;",B=D.attachShadow({mode:"closed"});let J=q.createElement("style");J.textContent=o,B.appendChild(J);let Q=q.createElement("div");Q.className="mfa-menu",B.appendChild(Q),q.documentElement.appendChild(D),b=kq(Q,I),Hq(Q),F=window.setInterval(()=>{if(b)b()},1000)}function s(){if(F!==null)window.clearInterval(F),F=null;if(b=null,B=null,D&&D.parentNode)D.parentNode.removeChild(D);D=null}function Rq(q,J){x(),_=q,I=J;let Q=q.ownerDocument;C=Q.createElement("div"),C.style.cssText="all: initial; position: fixed; z-index: 2147483646;",v=C.attachShadow({mode:"closed"});let X=Q.createElement("style");X.textContent=o,v.appendChild(X);let $=Q.createElement("button");$.type="button",$.className="mfa-button",$.setAttribute("aria-label",J.strings.fill),$.innerHTML=jq,v.appendChild($),Q.documentElement.appendChild(C),i(),$.addEventListener("mousedown",(Y)=>Y.preventDefault()),$.addEventListener("click",()=>{let Y=I,P=n(Y?.accounts??[],window.location.hostname);if(P.length===1){let L=Y?.onFill;x(),A.generateTOTP(P[0].secret).then((M)=>L?.(P[0],M)).catch(()=>{});return}if(D)s();else Iq()});let z=(Y)=>{if(Y.key==="Escape")x()},W=(Y)=>{let P=Y.target;if(!P)return;if(P===C||P===D)return;if(v&&v.contains(P))return;if(B&&B.contains(P))return;if(P===_)return;x()},Z=()=>{s(),i()},V=()=>{s(),i()},K=()=>{if(w!==null)window.clearTimeout(w);w=window.setTimeout(()=>{let Y=document.activeElement;if(Y===C||Y===D)return;if(_&&(Y===_||_.contains(Y)))return;x()},150)};Q.addEventListener("keydown",z,!0),Q.addEventListener("mousedown",W,!0),window.addEventListener("scroll",Z,!0),window.addEventListener("resize",V),Q.addEventListener("focusout",K,!0),Gq.push(()=>{Q.removeEventListener("keydown",z,!0),Q.removeEventListener("mousedown",W,!0),window.removeEventListener("scroll",Z,!0),window.removeEventListener("resize",V),Q.removeEventListener("focusout",K,!0)})}var e={"zh-CN":{fill:"填充",noAccounts:"暂无账户，请先在扩展中添加"},"zh-TW":{fill:"填充",noAccounts:"尚無帳戶，請先在擴充功能中新增"},"en-US":{fill:"Fill",noAccounts:"No accounts yet, add one in the extension"},"es-ES":{fill:"Rellenar",noAccounts:"No hay cuentas, añada una en la extensión"},"fr-FR":{fill:"Remplir",noAccounts:"Aucun compte, ajoutez-en un dans l'extension"},"pt-BR":{fill:"Preencher",noAccounts:"Nenhuma conta, adicione uma na extensão"},"de-DE":{fill:"Ausfüllen",noAccounts:"Keine Konten, fügen Sie eines in der Erweiterung hinzu"},"ru-RU":{fill:"Заполнить",noAccounts:"Нет учетных записей, добавьте в расширении"},"ar-SA":{fill:"تعبئة",noAccounts:"لا توجد حسابات، أضف واحدًا في الامتداد"},"ja-JP":{fill:"入力",noAccounts:"アカウントがありません。拡張機能で追加してください"},"ko-KR":{fill:"채우기",noAccounts:"계정이 없습니다. 확장 프로그램에서 추가하세요"},"hi-IN":{fill:"भरें",noAccounts:"कोई खाता नहीं, कृपया एक्सटेंशन में जोड़ें"}};function Tq(){let q=(navigator.language||"en").toLowerCase();if(q.startsWith("zh"))return q.startsWith("zh-tw")||q.startsWith("zh-hk")?"zh-TW":"zh-CN";if(q.startsWith("en"))return"en-US";if(q.startsWith("es"))return"es-ES";if(q.startsWith("fr"))return"fr-FR";if(q.startsWith("pt"))return"pt-BR";if(q.startsWith("de"))return"de-DE";if(q.startsWith("ru"))return"ru-RU";if(q.startsWith("ar"))return"ar-SA";if(q.startsWith("ja"))return"ja-JP";if(q.startsWith("ko"))return"ko-KR";if(q.startsWith("hi"))return"hi-IN";return"en-US"}function Sq(){return new Promise((q)=>{try{chrome.storage.sync.get("language",(J)=>{q(typeof J?.language==="string"?J.language:null)})}catch{q(null)}})}if(!globalThis.__MFA_CS_INITIALIZED__){globalThis.__MFA_CS_INITIALIZED__=!0;let q=[],J=T,Q=e["en-US"],X=null;async function $(){try{q=await S.getAccounts()}catch{q=[]}try{J=await S.getSettings()}catch{J=T}let z=await Sq();Q=e[z||Tq()]||e["en-US"]}chrome.storage.onChanged.addListener((z,W)=>{if(W==="sync"&&(z.accounts||z.autofillSettings||z.language))$()}),chrome.runtime.onMessage.addListener((z,W,Z)=>{if(!z||typeof z!=="object")return!1;let V=z;if(V.type==="PING"){let K=!1;try{K=!!m()||!!d()}catch{K=!1}return Z({ok:!0,hasField:K}),!1}if(V.type==="FILL_CODE"&&typeof V.code==="string"){x();let K=l(V.code);if(K.status==="filled"&&X&&X.isConnected)t(X);if(K.status==="no-field")return window.setTimeout(()=>{try{Z(K)}catch{}},300),!0;return Z(K),!1}return!1}),document.addEventListener("focusin",(z)=>{let W=z.target;if(!(W instanceof HTMLInputElement))return;if(!J.autofillInlineMenu)return;let Z=p(W),V=f(W)?E(W):null;if(!Z&&!V)return;X=W;let K=q.map((P)=>({name:P.name,secret:P.secret,website:P.website})),Y=n(K,window.location.hostname);Rq(W,{accounts:Y.length>0?Y:K,strings:Q,onFill:(P,L)=>{if(x(),l(L,W).status==="filled")t(W)}})},!0),$()}})();
