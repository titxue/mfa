(()=>{var{defineProperty:Qq,getOwnPropertyNames:xq,getOwnPropertyDescriptor:_q}=Object,Gq=Object.prototype.hasOwnProperty;function Oq(q){return this[q]}var Uq=(q)=>{var Q=($q??=new WeakMap).get(q),J;if(Q)return Q;if(Q=Qq({},"__esModule",{value:!0}),q&&typeof q==="object"||typeof q==="function"){for(var $ of xq(q))if(!Gq.call(Q,$))Qq(Q,$,{get:Oq.bind(q,$),enumerable:!(J=_q(q,$))||J.enumerable})}return $q.set(q,Q),Q},$q;var bq={};var b={autofillInlineMenu:!0,clipboardFallback:!0};class g{static isStorageAvailable(){return typeof chrome<"u"&&chrome.storage&&chrome.storage.sync!==void 0}static async getFromStorage(q,Q="sync"){try{if(this.isStorageAvailable())return(await chrome.storage[Q].get(q))[q];else{let J=localStorage.getItem(q);return J?JSON.parse(J):void 0}}catch(J){return}}static async saveToStorage(q,Q,J="sync"){try{if(this.isStorageAvailable())await chrome.storage[J].set({[q]:Q});else localStorage.setItem(q,JSON.stringify(Q))}catch($){}}static async getAccounts(){return await this.getFromStorage("accounts")||[]}static async saveAccounts(q){await this.saveToStorage("accounts",q)}static async getState(){return await this.getFromStorage("state")}static async saveState(q){await this.saveToStorage("state",q)}static async getLanguage(){return await this.getFromStorage("language")||"zh-CN"}static async saveLanguage(q){await this.saveToStorage("language",q)}static async removeLanguage(){try{if(this.isStorageAvailable())await chrome.storage.sync.remove("language");else localStorage.removeItem("language")}catch(q){}}static async getSettings(){let q=await this.getFromStorage("autofillSettings");return{...b,...q}}static async saveSettings(q){await this.saveToStorage("autofillSettings",q)}static async clear(){try{if(this.isStorageAvailable())await chrome.storage.sync.clear();else localStorage.clear()}catch(q){}}}var Zq=new Set(["text","tel","number","password"]),Nq=["otp","totp","2fa","mfa","authenticator","verification","verify","securitycode","onetime","onetim","one-time","验证码","动态码","安全码","双重验证","两步验证","一次性密码","驗證碼","動態碼","安全碼","雙重驗證","兩步驗證","一次性密碼","verificacion","autenticacion","vérification","verification","verifizierung","bestätigung","bestaetigung","подтверждени","проверочный","التحقق","認証コード","確認コード","ワンタイム","認証","인증","일회용","보안코드","सत्यापन"],vq=["login","signin","log in","sign in","verify","continue","submit","登录","登入","验证","继续","确认","提交","iniciarsesion","entrar","connexion","seconnecter","anmelden","einloggen","weiter","войти","продолжить","подтвердить","دخول","متابعة","ログイン","ログインする","次へ","로그인","계속","확인","साइनइन","लॉगइन","जारीरखें"];function c(q){return q.toLowerCase().replace(/[^a-z0-9\u00c0-\u024f\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af\u0600-\u06ff\u0900-\u097f]/g,"")}function Vq(q){if(q instanceof HTMLInputElement&&(q.disabled||q.readOnly))return!1;let Q=q.getClientRects();if(Q.length===0)return!1;let J=Q[0];return J.width>0&&J.height>0}function Bq(q){return[q.name,q.id,q.placeholder,q.getAttribute("aria-label"),q.getAttribute("autocomplete"),q.className,q.getAttribute("inputmode")].filter(Boolean).join(" ")}function Fq(q){let Q=[];if(q.labels){for(let $ of q.labels)if($.textContent)Q.push($.textContent)}let J=q.getAttribute("aria-labelledby");if(J)for(let $ of J.split(/\s+/)){let X=document.getElementById($);if(X&&X.textContent)Q.push(X.textContent)}return Q.join(" ")}function Xq(q){let Q=c(q);return Nq.some((J)=>Q.includes(J))}function Aq(q){let Q=q.parentElement;for(let J=0;J<4&&Q;J++){if(!(Q instanceof HTMLElement))break;let $=Q.querySelectorAll("input, button");for(let X of $){if(X===q)continue;if(X instanceof HTMLInputElement&&X.type==="password")return!0;if(X.tagName==="BUTTON"){let W=c(X.textContent||X.getAttribute("aria-label")||"");if(W&&vq.some((Z)=>W.includes(Z)))return!0}}Q=Q.parentElement}return!1}function Yq(q){if(!Zq.has(q.type))return 0;if(!Vq(q))return 0;let Q=(q.getAttribute("autocomplete")||"").toLowerCase();if(Q==="one-time-code")return 100;let J=Bq(q),$=Fq(q),X=q.maxLength,W=(q.getAttribute("inputmode")||"").toLowerCase(),Z=0;if(Xq(J))Z=Math.max(Z,80);if(Xq($))Z=Math.max(Z,70);if((W==="numeric"||W==="tel")&&X>=4&&X<=8)Z=Math.max(Z,55);if(c(J).includes("code")&&X>=4&&X<=8&&W==="numeric")Z=Math.max(Z,60);if(Z<50&&q.type!=="password"&&Aq(q))Z=Math.max(Z,45);if(Q==="off"&&Z<60)Z=Math.max(0,Z-20);return Z}function i(q){return Yq(q)>=40}function r(){let q=Array.from(document.querySelectorAll("input")),Q=null,J=0;for(let $ of q){let X=Yq($);if(X>J)J=X,Q=$}return J>=40?Q:null}function h(q){if(!Zq.has(q.type))return!1;if(!Vq(q))return!1;return q.maxLength===1||q.getAttribute("size")==="1"}function yq(q){return q.sort((Q,J)=>Q.compareDocumentPosition(J)&Node.DOCUMENT_POSITION_FOLLOWING?-1:1)}function p(q){let Q=Array.from(document.querySelectorAll("input")).filter(h),J=q.parentElement;for(let $=0;$<3&&J;$++){let X=Q.filter((W)=>W.parentElement===J||W.parentElement?.parentElement===J);if(X.length>=4&&X.length<=8)return yq(X);J=J.parentElement}return null}function s(){let q=Array.from(document.querySelectorAll("input"));for(let Q of q)if(h(Q)){let J=p(Q);if(J)return J}return null}function Kq(q,Q){let J=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"value");if(J&&J.set)J.set.call(q,Q);else q.value=Q}function Dq(q){q.dispatchEvent(new Event("input",{bubbles:!0,cancelable:!0})),q.dispatchEvent(new Event("change",{bubbles:!0,cancelable:!0}))}function jq(q){q.dataset.mfaFilled="true"}function zq(q,Q){return Kq(Q,q),Dq(Q),Q.focus(),jq(Q),{status:"filled",mode:"single"}}function Wq(q,Q){let J=q.replace(/\D/g,"");return Q.forEach((X,W)=>{if(W<J.length)Kq(X,J[W]),Dq(X),jq(X)}),(Q.find((X)=>X.value==="")||Q[Q.length-1]).focus(),{status:"filled",mode:"segmented"}}function a(q,Q){try{if(Q){let X=p(Q);if(X)return Wq(q,X);if(i(Q))return zq(q,Q)}let J=s();if(J)return Wq(q,J);let $=r();if($)return zq(q,$);return{status:"no-field",mode:"single"}}catch{return{status:"error",mode:"single"}}}function o(q,Q){return(q<<Q|q>>>32-Q)>>>0}function n(q){let Q=q.length,J=Q+1+(56-(Q+1)%64+64)%64+8,$=new Uint8Array(J);$.set(q),$[Q]=128;let X=new DataView($.buffer);X.setUint32(J-8,0,!1),X.setUint32(J-4,Q*8,!1);let W=1732584193,Z=4023233417,z=2562383102,V=271733878,Y=3285377520,j=new Uint32Array(80);for(let x=0;x<J;x+=64){for(let R=0;R<16;R++)j[R]=X.getUint32(x+R*4,!1);for(let R=16;R<80;R++)j[R]=o(j[R-3]^j[R-8]^j[R-14]^j[R-16],1);let _=W,P=Z,O=z,U=V,u=Y;for(let R=0;R<80;R++){let I,T;if(R<20)I=P&O|~P&U,T=1518500249;else if(R<40)I=P^O^U,T=1859775393;else if(R<60)I=P&O|P&U|O&U,T=2400959708;else I=P^O^U,T=3395469782;let Mq=o(_,5)+I+u+T+j[R]|0;u=U,U=O,O=o(P,30),P=_,_=Mq}W=W+_|0,Z=Z+P|0,z=z+O|0,V=V+U|0,Y=Y+u|0}let D=new Uint8Array(20),K=new DataView(D.buffer);return K.setUint32(0,W,!1),K.setUint32(4,Z,!1),K.setUint32(8,z,!1),K.setUint32(12,V,!1),K.setUint32(16,Y,!1),D}function Pq(q,Q){let J=q;if(J.length>64)J=n(J);let $=new Uint8Array(64).fill(54),X=new Uint8Array(64).fill(92);for(let V=0;V<J.length;V++)$[V]^=J[V],X[V]^=J[V];let W=new Uint8Array($.length+Q.length);W.set($),W.set(Q,$.length);let Z=n(W),z=new Uint8Array(X.length+Z.length);return z.set(X),z.set(Z,X.length),n(z)}class y{static BASE32_CHARS="ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";static base32Decode(q){let Q="",J=q.toUpperCase().replace(/\s/g,"");for(let X=0;X<J.length;X++){let W=this.BASE32_CHARS.indexOf(J[X]);if(W===-1)throw Error("Invalid base32 character");Q+=W.toString(2).padStart(5,"0")}let $=new Uint8Array(Math.floor(Q.length/8));for(let X=0;X<$.length;X++)$[X]=parseInt(Q.substr(X*8,8),2);return $}static async generateTOTP(q,Q=30){let J=this.base32Decode(q),$=Math.floor(Date.now()/1000/Q),X=new ArrayBuffer(8);new DataView(X).setBigUint64(0,BigInt($),!1);let Z;if(typeof crypto<"u"&&crypto.subtle){let Y=await crypto.subtle.importKey("raw",J,{name:"HMAC",hash:"SHA-1"},!1,["sign"]),j=await crypto.subtle.sign("HMAC",Y,X);Z=new Uint8Array(j)}else Z=Pq(J,new Uint8Array(X));let z=Z[19]&15;return(((Z[z]&127)<<24|(Z[z+1]&255)<<16|(Z[z+2]&255)<<8|Z[z+3]&255)%1e6).toString().padStart(6,"0")}static getRemainingSeconds(q=30){return q-Math.floor(Date.now()/1000)%q}static formatCode(q){return`${q.slice(0,3)} ${q.slice(3)}`}}var S=24,f=6,qq=`
.mfa-button {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 24px;
  height: 24px;
  padding: 0;
  border-radius: 6px;
  background: hsl(0 0% 100%);
  border: 1px solid hsl(240 5.9% 90%);
  color: hsl(240 5.9% 10%);
  cursor: pointer;
  box-shadow: 0 1px 2px rgb(0 0 0 / 0.1);
  transition: background-color 150ms;
  font-family: inherit;
}
.mfa-button:hover {
  background: hsl(240 4.8% 95.9%);
}
.mfa-button:focus-visible { outline: 2px solid hsl(240 5.9% 10%); outline-offset: 2px; }
.mfa-button:active { transform: scale(0.96); }
.mfa-button svg {
  display: block;
}
.mfa-menu {
  box-sizing: border-box;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'Noto Sans', sans-serif;
  background: hsl(0 0% 100%);
  color: hsl(240 10% 3.9%);
  border: 1px solid hsl(240 5.9% 90%);
  border-radius: 0.5rem;
  box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
  min-width: 220px;
  max-width: 320px;
  max-height: 280px;
  overflow-y: auto;
  padding: 4px;
  animation: mfa-menu-in 120ms ease-out;
}
@keyframes mfa-menu-in {
  from { opacity: 0; transform: scale(0.95); }
  to { opacity: 1; transform: scale(1); }
}
.mfa-menu::-webkit-scrollbar { display: none; }
.mfa-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 8px;
  border-radius: 4px;
  cursor: pointer;
  user-select: none;
  transition: background-color 150ms;
}
.mfa-item:hover,
.mfa-item:focus-visible {
  background: hsl(240 4.8% 95.9%);
  outline: none;
}
.mfa-item-icon {
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 30px;
  height: 30px;
  border-radius: 6px;
  background: hsl(240 4.8% 95.9%);
  color: hsl(240 3.8% 46.1%);
  transition: color 150ms;
}
.mfa-item:hover .mfa-item-icon {
  color: hsl(240 5.9% 10%);
}
.mfa-item-main {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.mfa-item-name {
  font-size: 14px;
  font-weight: 500;
  color: hsl(240 10% 3.9%);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.mfa-item-code {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, 'Liberation Mono', monospace;
  font-size: 14px;
  font-weight: 600;
  letter-spacing: 0.05em;
  color: hsl(240 5.9% 10%);
}
.mfa-item-fill {
  flex-shrink: 0;
  padding: 5px 10px;
  border-radius: 6px;
  border: 1px solid hsl(240 5.9% 90%);
  background: hsl(0 0% 100%);
  color: hsl(240 5.9% 10%);
  font-size: 12px;
  font-weight: 500;
  font-family: inherit;
  cursor: pointer;
  transition: background-color 150ms;
}
.mfa-item:hover .mfa-item-fill {
  background: hsl(240 5.9% 10%);
  color: hsl(0 0% 98%);
  border-color: transparent;
}
.mfa-item-fill:focus-visible {
  outline: none;
  background: hsl(240 5.9% 10%);
  color: hsl(0 0% 98%);
  border-color: transparent;
}
.mfa-feedback-badge {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 28px;
  padding: 4px 10px;
  gap: 6px;
  white-space: nowrap;
  border-radius: 6px;
  border: 1px solid hsl(240 5.9% 90%);
  background: hsl(0 0% 100%);
  color: hsl(240 5.9% 10%);
  font-size: 12px;
  font-weight: 500;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  box-shadow: 0 1px 2px rgb(0 0 0 / 0.15);
  animation: mfa-feedback-in 150ms ease-out;
}
@keyframes mfa-feedback-in {
  from { opacity: 0; transform: scale(0.6); }
  to { opacity: 1; transform: scale(1); }
}
.mfa-empty {
  padding: 6px 8px;
  font-size: 14px;
  color: hsl(240 3.8% 46.1%);
}
@media (prefers-reduced-motion: reduce) {
  .mfa-menu, .mfa-feedback-badge { animation: none; }
  .mfa-button, .mfa-item, .mfa-item-fill { transition: none; }
}
`,Cq='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="7.5" cy="15.5" r="5.5"/><path d="m21 2-9.6 9.6"/><path d="m15.5 7.5 3 3L22 7l-3-3"/></svg>',Hq=new Set(["com","net","org","io","co","cn","jp","de","ru","fr","es","br","in","kr","tw","hk","uk","au","ca","me","app","dev","site","top","xyz","online","store","shop","gov","edu","info","biz","cloud","work","live"]);function wq(q){return q.toLowerCase().replace(/[^a-z0-9\u00c0-\u024f\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af\u0600-\u06ff\u0900-\u097f]/g,"")}function e(q,Q){let J=Q.toLowerCase();if(q.website)try{let W=new URL(q.website).hostname.toLowerCase();if(J===W||J.endsWith("."+W)||W.endsWith("."+J))return!0}catch{}let $=wq(q.name);if(!$)return!1;return J.split(".").filter((W)=>W&&!Hq.has(W)).some((W)=>{if(W.length>=3&&$.includes(W))return!0;if($.length>=4&&W.includes($))return!0;return!1})}function Jq(q,Q){return q.filter((J)=>e(J,Q))}var v=null,B=[],w=null,M=null,H=null,C=null,F=null,A=null,d=null,N=null,Rq=[],E=null,L=null;function k(q,Q="✓"){if(E!==null)window.clearTimeout(E),E=null;if(L&&L.parentNode)L.parentNode.removeChild(L),L=null;let J=q.ownerDocument;L=J.createElement("div"),L.style.cssText="all: initial; position: fixed; z-index: 2147483647;";let $=L.attachShadow({mode:"closed"}),X=J.createElement("style");X.textContent=qq,$.appendChild(X);let W=J.createElement("div");W.className="mfa-feedback-badge",W.textContent=Q,W.setAttribute("role","status"),W.setAttribute("aria-live","polite"),L.style.pointerEvents="none",$.appendChild(W);let Z=q.getBoundingClientRect();J.documentElement.appendChild(L);let z=L.getBoundingClientRect().width,V=Math.min(Math.max(Z.left,4),Math.max(4,window.innerWidth-z-4)),Y=Z.bottom+6+28>window.innerHeight?Math.max(4,Z.top-34):Z.bottom+6;L.style.left=Math.round(V)+"px",L.style.top=Math.round(Y)+"px",J.documentElement.appendChild(L),E=window.setTimeout(()=>{if(L&&L.parentNode)L.parentNode.removeChild(L);L=null,E=null},1600)}function G(){if(N!==null)window.clearTimeout(N),N=null;for(let q of Rq.splice(0))try{q()}catch{}if(A!==null)window.clearInterval(A),A=null;if(v=null,B=[],w=null,H=null,F=null,C&&C.parentNode)C.parentNode.removeChild(C);if(C=null,M&&M.parentNode)M.parentNode.removeChild(M);M=null}function m(){if(!M||!v)return;let q=B.filter((z)=>z.isConnected).map((z)=>z.getBoundingClientRect()).filter((z)=>z.width>0&&z.height>0),Q=B.length>1,J=Q&&q.length?{left:Math.min(...q.map((z)=>z.left)),right:Math.max(...q.map((z)=>z.right)),top:Math.min(...q.map((z)=>z.top)),bottom:Math.max(...q.map((z)=>z.bottom)),width:Math.max(...q.map((z)=>z.right))-Math.min(...q.map((z)=>z.left)),height:Math.max(...q.map((z)=>z.bottom))-Math.min(...q.map((z)=>z.top))}:v.getBoundingClientRect();if(J.width<=0||J.height<=0){G();return}let $=J.right+f+S<=window.innerWidth-4,X=Q?$?J.right+f:J.right-S:J.right-S-4,W=Math.min(Math.max(X,4),Math.max(4,window.innerWidth-S-4)),Z=Q&&!$?J.bottom+f:J.top+Math.max(0,(J.height-S)/2);M.style.left=Math.round(W)+"px",M.style.top=Math.round(Z)+"px"}function kq(q){if(!C||!M)return;let Q=M.getBoundingClientRect(),J=Math.min(Math.max(q.offsetWidth,220),320),$=q.offsetHeight,X=window.innerWidth,W=window.innerHeight,Z=Q.bottom+f;if(Z+$>W-8)Z=Math.max(8,Q.top-f-$);let z=Math.min(Math.max(Q.left,8),Math.max(8,X-8-J));C.style.left=Math.round(z)+"px",C.style.top=Math.round(Z)+"px"}function Iq(q,Q){let J=q.ownerDocument;q.innerHTML="";let $=[...Q.accounts].sort((z,V)=>Number(e(V,window.location.hostname))-Number(e(z,window.location.hostname)));if($.length===0){let z=J.createElement("div");return z.className="mfa-empty",z.textContent=Q.strings.noAccounts,q.appendChild(z),()=>{}}let X=new Map;for(let z of $){let V=J.createElement("div");V.className="mfa-item",V.setAttribute("role","button"),V.tabIndex=0;let Y=J.createElement("span");Y.className="mfa-item-icon",Y.innerHTML=Cq;let j=J.createElement("div");j.className="mfa-item-main";let D=J.createElement("div");D.className="mfa-item-name",D.textContent=z.name;let K=J.createElement("div");K.className="mfa-item-code",K.textContent="······",X.set(z,K),j.appendChild(D),j.appendChild(K);let x=J.createElement("button");x.type="button",x.className="mfa-item-fill",x.textContent=Q.strings.fill,V.appendChild(Y),V.appendChild(j),V.appendChild(x);let _=()=>{let P=Q.onFill,O=v;G(),y.generateTOTP(z.secret).then((U)=>P(z,U)).catch(()=>{if(O)k(O,Q.strings.failed??"!")})};V.addEventListener("click",_),x.addEventListener("click",(P)=>{P.stopPropagation(),_()}),V.addEventListener("keydown",(P)=>{if(P.key==="Enter"||P.key===" ")P.preventDefault(),_()}),q.appendChild(V)}let W=Array.from(q.querySelectorAll(".mfa-item"));if(W.length>0)W[0].focus();q.addEventListener("keydown",(z)=>{let V=Array.from(q.querySelectorAll(".mfa-item")),Y=V.indexOf(z.target);if(z.key==="ArrowDown")z.preventDefault(),V[Math.min(V.length-1,Y+1)]?.focus();else if(z.key==="ArrowUp")z.preventDefault(),V[Math.max(0,Y-1)]?.focus();else if(z.key==="Home")z.preventDefault(),V[0]?.focus();else if(z.key==="End")z.preventDefault(),V[V.length-1]?.focus()});let Z=()=>{for(let[z,V]of X)y.generateTOTP(z.secret).then((Y)=>{if(V.isConnected)V.textContent=y.formatCode(Y)}).catch(()=>{})};return Z(),Z}function Tq(){if(!v||!w||C)return;let q=v.ownerDocument;C=q.createElement("div"),C.style.cssText="all: initial; position: fixed; z-index: 2147483647;",F=C.attachShadow({mode:"closed"});let Q=q.createElement("style");Q.textContent=qq,F.appendChild(Q);let J=q.createElement("div");J.className="mfa-menu",F.appendChild(J),q.documentElement.appendChild(C),d=Iq(J,w),kq(J),A=window.setInterval(()=>{if(d)d()},1000)}function t(){if(A!==null)window.clearInterval(A),A=null;if(d=null,F=null,C&&C.parentNode)C.parentNode.removeChild(C);C=null}function Lq(q,Q){let J=Q.inputGroup??[q];if(M&&J.length>1&&J.length===B.length&&J.every((D,K)=>D===B[K])){if(v=q,w=Q,N!==null)window.clearTimeout(N),N=null;m();return}G(),v=q,B=J,w=Q;let $=q.ownerDocument;M=$.createElement("div"),M.style.cssText="all: initial; position: fixed; z-index: 2147483646;",H=M.attachShadow({mode:"closed"});let X=$.createElement("style");X.textContent=qq,H.appendChild(X);let W=$.createElement("button");W.type="button",W.className="mfa-button",W.setAttribute("aria-label",Q.strings.fill),W.innerHTML=Cq,H.appendChild(W),$.documentElement.appendChild(M),m(),W.addEventListener("mousedown",(D)=>D.preventDefault()),W.addEventListener("click",()=>{let D=w,K=Jq(D?.accounts??[],window.location.hostname);if(K.length===1){let x=D?.onFill,_=v;G(),y.generateTOTP(K[0].secret).then((P)=>x?.(K[0],P)).catch(()=>{if(_)k(_,D?.strings.failed??"!")});return}if(C)t();else Tq()});let Z=(D)=>{if(D.key==="Escape")G()},z=(D)=>{let K=D.target;if(!K)return;if(K===M||K===C)return;if(H&&H.contains(K))return;if(F&&F.contains(K))return;if(B.some((x)=>K===x))return;G()},V=()=>{t(),m()},Y=()=>{t(),m()},j=()=>{if(N!==null)window.clearTimeout(N);N=window.setTimeout(()=>{let D=document.activeElement;if(D===M||D===C)return;if(B.some((K)=>D===K))return;G()},150)};$.addEventListener("keydown",Z,!0),$.addEventListener("mousedown",z,!0),window.addEventListener("scroll",V,!0),window.addEventListener("resize",Y),$.addEventListener("focusout",j,!0),Rq.push(()=>{$.removeEventListener("keydown",Z,!0),$.removeEventListener("mousedown",z,!0),window.removeEventListener("scroll",V,!0),window.removeEventListener("resize",Y),$.removeEventListener("focusout",j,!0)})}var l={"zh-CN":{fill:"填充",noAccounts:"暂无账户，请先在扩展中添加"},"zh-TW":{fill:"填充",noAccounts:"尚無帳戶，請先在擴充功能中新增"},"en-US":{fill:"Fill",noAccounts:"No accounts yet, add one in the extension"},"es-ES":{fill:"Rellenar",noAccounts:"No hay cuentas, añada una en la extensión"},"fr-FR":{fill:"Remplir",noAccounts:"Aucun compte, ajoutez-en un dans l'extension"},"pt-BR":{fill:"Preencher",noAccounts:"Nenhuma conta, adicione uma na extensão"},"de-DE":{fill:"Ausfüllen",noAccounts:"Keine Konten, fügen Sie eines in der Erweiterung hinzu"},"ru-RU":{fill:"Заполнить",noAccounts:"Нет учетных записей, добавьте в расширении"},"ar-SA":{fill:"تعبئة",noAccounts:"لا توجد حسابات، أضف واحدًا في الامتداد"},"ja-JP":{fill:"入力",noAccounts:"アカウントがありません。拡張機能で追加してください"},"ko-KR":{fill:"채우기",noAccounts:"계정이 없습니다. 확장 프로그램에서 추가하세요"},"hi-IN":{fill:"भरें",noAccounts:"कोई खाता नहीं, कृपया एक्सटेंशन में जोड़ें"}},Sq={"zh-CN":["✓ 已填充","未能填充，请重试"],"zh-TW":["✓ 已填入","無法填入，請重試"],"en-US":["✓ Filled","Could not fill. Try again."],"es-ES":["✓ Completado","No se pudo rellenar. Reinténtalo."],"fr-FR":["✓ Rempli","Échec du remplissage. Réessayez."],"pt-BR":["✓ Preenchido","Não foi possível preencher. Tente novamente."],"de-DE":["✓ Ausgefüllt","Ausfüllen fehlgeschlagen. Erneut versuchen."],"ru-RU":["✓ Заполнено","Не удалось заполнить. Повторите."],"ar-SA":["✓ تمت التعبئة","تعذرت التعبئة. حاول مجدداً."],"ja-JP":["✓ 入力済み","入力できませんでした。再試行してください。"],"ko-KR":["✓ 입력 완료","입력하지 못했습니다. 다시 시도하세요."],"hi-IN":["✓ भर दिया गया","भर नहीं सके। फिर कोशिश करें।"]};for(let[q,[Q,J]]of Object.entries(Sq))Object.assign(l[q],{filled:Q,failed:J});function Eq(){let q=(navigator.language||"en").toLowerCase();if(q.startsWith("zh"))return q.startsWith("zh-tw")||q.startsWith("zh-hk")?"zh-TW":"zh-CN";if(q.startsWith("en"))return"en-US";if(q.startsWith("es"))return"es-ES";if(q.startsWith("fr"))return"fr-FR";if(q.startsWith("pt"))return"pt-BR";if(q.startsWith("de"))return"de-DE";if(q.startsWith("ru"))return"ru-RU";if(q.startsWith("ar"))return"ar-SA";if(q.startsWith("ja"))return"ja-JP";if(q.startsWith("ko"))return"ko-KR";if(q.startsWith("hi"))return"hi-IN";return"en-US"}function fq(){return new Promise((q)=>{try{chrome.storage.sync.get("language",(Q)=>{q(typeof Q?.language==="string"?Q.language:null)})}catch{q(null)}})}if(!globalThis.__MFA_CS_INITIALIZED__){globalThis.__MFA_CS_INITIALIZED__=!0;let q=[],Q=b,J=l["en-US"],$=null,X=!1,W=0;async function Z(){let V=++W,Y=!1;try{Y=(await chrome.runtime.sendMessage({type:"SITE_ACCESS_CHECK"}))?.allowed===!0}catch{}if(V!==W)return!1;if(X=Y,!Y)G(),q=[];return Y}async function z(){let V=await Z();try{if(q=V?await g.getAccounts():[],!X)q=[]}catch{q=[]}try{Q=await g.getSettings()}catch{Q=b}let Y=await fq();if(J=l[Y||Eq()]||l["en-US"],!X||!Q.autofillInlineMenu)G()}chrome.storage.onChanged.addListener((V,Y)=>{if(Y==="sync"&&(V.accounts||V.autofillSettings||V.language))z()}),chrome.runtime.onMessage.addListener((V,Y,j)=>{if(!V||typeof V!=="object")return!1;let D=V;if(D.type==="SITE_ACCESS_CHANGED")return X=!1,q=[],G(),z(),!1;if(D.type==="PING"){let K=!1;try{K=!!r()||!!s()}catch{K=!1}return j({ok:!0,hasField:K}),!1}if(D.type==="FILL_CODE"&&typeof D.code==="string"){G();let K=a(D.code);if(K.status==="filled"&&$&&$.isConnected)k($,J.filled);if(K.status==="no-field")return window.setTimeout(()=>{try{j(K)}catch{}},300),!0;return j(K),!1}return!1}),document.addEventListener("focusin",async(V)=>{let Y=V.target;if(!(Y instanceof HTMLInputElement))return;if(!Q.autofillInlineMenu)return;if(!await Z())return;if(document.activeElement!==Y)return;let j=i(Y),D=h(Y)?p(Y):null;if(!j&&!D)return;$=Y;let K=q.map((_)=>({name:_.name,secret:_.secret,website:_.website})),x=Jq(K,window.location.hostname);Lq(Y,{inputGroup:D??void 0,accounts:x.length>0?x:K,strings:J,onFill:async(_,P)=>{if(!await Z())return;if(G(),a(P,Y).status==="filled")k(Y,J.filled);else k(Y,J.failed)}})},!0),z()}})();
