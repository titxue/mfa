(()=>{var{defineProperty:qq,getOwnPropertyNames:Lq,getOwnPropertyDescriptor:Mq}=Object,_q=Object.prototype.hasOwnProperty;function xq(q){return this[q]}var Nq=(q)=>{var J=(Jq??=new WeakMap).get(q),Q;if(J)return J;if(J=qq({},"__esModule",{value:!0}),q&&typeof q==="object"||typeof q==="function"){for(var X of Lq(q))if(!_q.call(J,X))qq(J,X,{get:xq.bind(q,X),enumerable:!(Q=Mq(q,X))||Q.enumerable})}return Jq.set(q,J),J},Jq;var Eq={};var T={autofillInlineMenu:!0,clipboardFallback:!0};class S{static isStorageAvailable(){return typeof chrome<"u"&&chrome.storage&&chrome.storage.sync!==void 0}static async getFromStorage(q,J="sync"){try{if(this.isStorageAvailable())return(await chrome.storage[J].get(q))[q];else{let Q=localStorage.getItem(q);return Q?JSON.parse(Q):void 0}}catch(Q){return}}static async saveToStorage(q,J,Q="sync"){try{if(this.isStorageAvailable())await chrome.storage[Q].set({[q]:J});else localStorage.setItem(q,JSON.stringify(J))}catch(X){}}static async getAccounts(){return await this.getFromStorage("accounts")||[]}static async saveAccounts(q){await this.saveToStorage("accounts",q)}static async getState(){return await this.getFromStorage("state")}static async saveState(q){await this.saveToStorage("state",q)}static async getLanguage(){return await this.getFromStorage("language")||"zh-CN"}static async saveLanguage(q){await this.saveToStorage("language",q)}static async removeLanguage(){try{if(this.isStorageAvailable())await chrome.storage.sync.remove("language");else localStorage.removeItem("language")}catch(q){}}static async getSettings(){let q=await this.getFromStorage("autofillSettings");return{...T,...q}}static async saveSettings(q){await this.saveToStorage("autofillSettings",q)}static async clear(){try{if(this.isStorageAvailable())await chrome.storage.sync.clear();else localStorage.clear()}catch(q){}}}var zq=new Set(["text","tel","number","password"]),Oq=["otp","totp","2fa","mfa","authenticator","verification","verify","securitycode","onetime","onetim","one-time","验证码","动态码","安全码","双重验证","两步验证","一次性密码","驗證碼","動態碼","安全碼","雙重驗證","兩步驗證","一次性密碼","verificacion","autenticacion","vérification","verification","verifizierung","bestätigung","bestaetigung","подтверждени","проверочный","التحقق","認証コード","確認コード","ワンタイム","認証","인증","일회용","보안코드","सत्यापन"],Uq=["login","signin","log in","sign in","verify","continue","submit","登录","登入","验证","继续","确认","提交","iniciarsesion","entrar","connexion","seconnecter","anmelden","einloggen","weiter","войти","продолжить","подтвердить","دخول","متابعة","ログイン","ログインする","次へ","로그인","계속","확인","साइनइन","लॉगइन","जारीरखें"];function h(q){return q.toLowerCase().replace(/[^a-z0-9\u00c0-\u024f\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af\u0600-\u06ff\u0900-\u097f]/g,"")}function Wq(q){if(q instanceof HTMLInputElement&&(q.disabled||q.readOnly))return!1;let J=q.getClientRects();if(J.length===0)return!1;let Q=J[0];return Q.width>0&&Q.height>0}function Bq(q){return[q.name,q.id,q.placeholder,q.getAttribute("aria-label"),q.getAttribute("autocomplete"),q.className,q.getAttribute("inputmode")].filter(Boolean).join(" ")}function Fq(q){let J=[];if(q.labels){for(let X of q.labels)if(X.textContent)J.push(X.textContent)}let Q=q.getAttribute("aria-labelledby");if(Q)for(let X of Q.split(/\s+/)){let $=document.getElementById(X);if($&&$.textContent)J.push($.textContent)}return J.join(" ")}function Qq(q){let J=h(q);return Oq.some((Q)=>J.includes(Q))}function vq(q){let J=q.parentElement;for(let Q=0;Q<4&&J;Q++){if(!(J instanceof HTMLElement))break;let X=J.querySelectorAll("input, button");for(let $ of X){if($===q)continue;if($ instanceof HTMLInputElement&&$.type==="password")return!0;if($.tagName==="BUTTON"){let W=h($.textContent||$.getAttribute("aria-label")||"");if(W&&Uq.some((Z)=>W.includes(Z)))return!0}}J=J.parentElement}return!1}function Zq(q){if(!zq.has(q.type))return 0;if(!Wq(q))return 0;let J=(q.getAttribute("autocomplete")||"").toLowerCase();if(J==="one-time-code")return 100;let Q=Bq(q),X=Fq(q),$=q.maxLength,W=(q.getAttribute("inputmode")||"").toLowerCase(),Z=0;if(Qq(Q))Z=Math.max(Z,80);if(Qq(X))Z=Math.max(Z,70);if((W==="numeric"||W==="tel")&&$>=4&&$<=8)Z=Math.max(Z,55);if(h(Q).includes("code")&&$>=4&&$<=8&&W==="numeric")Z=Math.max(Z,60);if(Z<50&&q.type!=="password"&&vq(q))Z=Math.max(Z,45);if(J==="off"&&Z<60)Z=Math.max(0,Z-20);return Z}function p(q){return Zq(q)>=40}function m(){let q=Array.from(document.querySelectorAll("input")),J=null,Q=0;for(let X of q){let $=Zq(X);if($>Q)Q=$,J=X}return Q>=40?J:null}function E(q){if(!zq.has(q.type))return!1;if(!Wq(q))return!1;return q.maxLength===1||q.getAttribute("size")==="1"}function Aq(q){return q.sort((J,Q)=>J.compareDocumentPosition(Q)&Node.DOCUMENT_POSITION_FOLLOWING?-1:1)}function f(q){let J=Array.from(document.querySelectorAll("input")).filter(E),Q=q.parentElement;for(let X=0;X<3&&Q;X++){let $=J.filter((W)=>W.parentElement===Q||W.parentElement?.parentElement===Q);if($.length>=4&&$.length<=8)return Aq($);Q=Q.parentElement}return null}function d(){let q=Array.from(document.querySelectorAll("input"));for(let J of q)if(E(J)){let Q=f(J);if(Q)return Q}return null}function Vq(q,J){let Q=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"value");if(Q&&Q.set)Q.set.call(q,J);else q.value=J}function Yq(q){q.dispatchEvent(new Event("input",{bubbles:!0,cancelable:!0})),q.dispatchEvent(new Event("change",{bubbles:!0,cancelable:!0}))}function Kq(q){q.dataset.mfaFilled="true"}function $q(q,J){return Vq(J,q),Yq(J),J.focus(),Kq(J),{status:"filled",mode:"single"}}function Xq(q,J){let Q=q.replace(/\D/g,"");return J.forEach(($,W)=>{if(W<Q.length)Vq($,Q[W]),Yq($),Kq($)}),(J.find(($)=>$.value==="")||J[J.length-1]).focus(),{status:"filled",mode:"segmented"}}function l(q,J){try{if(J){let $=f(J);if($)return Xq(q,$);if(p(J))return $q(q,J)}let Q=d();if(Q)return Xq(q,Q);let X=m();if(X)return $q(q,X);return{status:"no-field",mode:"single"}}catch{return{status:"error",mode:"single"}}}function u(q,J){return(q<<J|q>>>32-J)>>>0}function r(q){let J=q.length,Q=J+1+(56-(J+1)%64+64)%64+8,X=new Uint8Array(Q);X.set(q),X[J]=128;let $=new DataView(X.buffer);$.setUint32(Q-8,0,!1),$.setUint32(Q-4,J*8,!1);let W=1732584193,Z=4023233417,V=2562383102,z=271733878,Y=3285377520,K=new Uint32Array(80);for(let M=0;M<Q;M+=64){for(let C=0;C<16;C++)K[C]=$.getUint32(M+C*4,!1);for(let C=16;C<80;C++)K[C]=u(K[C-3]^K[C-8]^K[C-14]^K[C-16],1);let _=W,G=Z,N=V,U=z,g=Y;for(let C=0;C<80;C++){let y,H;if(C<20)y=G&N|~G&U,H=1518500249;else if(C<40)y=G^N^U,H=1859775393;else if(C<60)y=G&N|G&U|N&U,H=2400959708;else y=G^N^U,H=3395469782;let Rq=u(_,5)+y+g+H+K[C]|0;g=U,U=N,N=u(G,30),G=_,_=Rq}W=W+_|0,Z=Z+G|0,V=V+N|0,z=z+U|0,Y=Y+g|0}let P=new Uint8Array(20),D=new DataView(P.buffer);return D.setUint32(0,W,!1),D.setUint32(4,Z,!1),D.setUint32(8,V,!1),D.setUint32(12,z,!1),D.setUint32(16,Y,!1),P}function Pq(q,J){let Q=q;if(Q.length>64)Q=r(Q);let X=new Uint8Array(64).fill(54),$=new Uint8Array(64).fill(92);for(let z=0;z<Q.length;z++)X[z]^=Q[z],$[z]^=Q[z];let W=new Uint8Array(X.length+J.length);W.set(X),W.set(J,X.length);let Z=r(W),V=new Uint8Array($.length+Z.length);return V.set($),V.set(Z,$.length),r(V)}class v{static BASE32_CHARS="ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";static base32Decode(q){let J="",Q=q.toUpperCase().replace(/\s/g,"");for(let $=0;$<Q.length;$++){let W=this.BASE32_CHARS.indexOf(Q[$]);if(W===-1)throw Error("Invalid base32 character");J+=W.toString(2).padStart(5,"0")}let X=new Uint8Array(Math.floor(J.length/8));for(let $=0;$<X.length;$++)X[$]=parseInt(J.substr($*8,8),2);return X}static async generateTOTP(q,J=30){let Q=this.base32Decode(q),X=Math.floor(Date.now()/1000/J),$=new ArrayBuffer(8);new DataView($).setBigUint64(0,BigInt(X),!1);let Z;if(typeof crypto<"u"&&crypto.subtle){let Y=await crypto.subtle.importKey("raw",Q,{name:"HMAC",hash:"SHA-1"},!1,["sign"]),K=await crypto.subtle.sign("HMAC",Y,$);Z=new Uint8Array(K)}else Z=Pq(Q,new Uint8Array($));let V=Z[19]&15;return(((Z[V]&127)<<24|(Z[V+1]&255)<<16|(Z[V+2]&255)<<8|Z[V+3]&255)%1e6).toString().padStart(6,"0")}static getRemainingSeconds(q=30){return q-Math.floor(Date.now()/1000)%q}static formatCode(q){return`${q.slice(0,3)} ${q.slice(3)}`}}var c=24,Dq=6,o=`
.mfa-button {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 24px;
  height: 24px;
  padding: 0;
  border-radius: 9999px;
  background: hsl(0 0% 100%);
  border: 1px solid hsl(240 5.9% 90%);
  color: hsl(240 5.9% 10%);
  cursor: pointer;
  box-shadow: 0 1px 2px rgb(0 0 0 / 0.1);
  transition: background-color 150ms;
  font-family: inherit;
}
.mfa-button:hover {
  background: hsl(240 4.8% 95.9%);
}
.mfa-button svg {
  display: block;
}
.mfa-menu {
  box-sizing: border-box;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'Noto Sans', sans-serif;
  background: hsl(0 0% 100%);
  color: hsl(240 10% 3.9%);
  border: 1px solid hsl(240 5.9% 90%);
  border-radius: 0.5rem;
  box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
  min-width: 220px;
  max-width: 320px;
  max-height: 280px;
  overflow-y: auto;
  padding: 4px;
  animation: mfa-menu-in 120ms ease-out;
}
@keyframes mfa-menu-in {
  from { opacity: 0; transform: scale(0.95); }
  to { opacity: 1; transform: scale(1); }
}
.mfa-menu::-webkit-scrollbar { display: none; }
.mfa-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 8px;
  border-radius: 4px;
  cursor: pointer;
  user-select: none;
  transition: background-color 150ms;
}
.mfa-item:hover,
.mfa-item:focus-visible {
  background: hsl(240 4.8% 95.9%);
  outline: none;
}
.mfa-item-icon {
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 26px;
  height: 26px;
  border-radius: 9999px;
  background: hsl(240 4.8% 95.9%);
  color: hsl(240 3.8% 46.1%);
  transition: color 150ms;
}
.mfa-item:hover .mfa-item-icon {
  color: hsl(240 5.9% 10%);
}
.mfa-item-main {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.mfa-item-name {
  font-size: 14px;
  font-weight: 500;
  color: hsl(240 10% 3.9%);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.mfa-item-code {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, 'Liberation Mono', monospace;
  font-size: 14px;
  font-weight: 700;
  letter-spacing: 0.05em;
  color: hsl(240 5.9% 10%);
}
.mfa-item-fill {
  flex-shrink: 0;
  padding: 3px 10px;
  border-radius: 4px;
  border: 1px solid hsl(240 5.9% 90%);
  background: hsl(0 0% 100%);
  color: hsl(240 5.9% 10%);
  font-size: 12px;
  font-weight: 500;
  font-family: inherit;
  cursor: pointer;
  transition: background-color 150ms;
}
.mfa-item:hover .mfa-item-fill {
  background: hsl(240 5.9% 10%);
  color: hsl(0 0% 98%);
  border-color: transparent;
}
.mfa-item-fill:focus-visible {
  outline: none;
  background: hsl(240 5.9% 10%);
  color: hsl(0 0% 98%);
  border-color: transparent;
}
.mfa-feedback-badge {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 20px;
  height: 20px;
  border-radius: 9999px;
  background: hsl(142 76% 36%);
  color: #fff;
  font-size: 12px;
  font-weight: 700;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  box-shadow: 0 1px 2px rgb(0 0 0 / 0.15);
  animation: mfa-feedback-in 150ms ease-out;
}
@keyframes mfa-feedback-in {
  from { opacity: 0; transform: scale(0.6); }
  to { opacity: 1; transform: scale(1); }
}
.mfa-empty {
  padding: 6px 8px;
  font-size: 14px;
  color: hsl(240 3.8% 46.1%);
}
`,jq='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="7.5" cy="15.5" r="5.5"/><path d="m21 2-9.6 9.6"/><path d="m15.5 7.5 3 3L22 7l-3-3"/></svg>',wq=new Set(["com","net","org","io","co","cn","jp","de","ru","fr","es","br","in","kr","tw","hk","uk","au","ca","me","app","dev","site","top","xyz","online","store","shop","gov","edu","info","biz","cloud","work","live"]);function yq(q){return q.toLowerCase().replace(/[^a-z0-9\u00c0-\u024f\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af\u0600-\u06ff\u0900-\u097f]/g,"")}function a(q,J){let Q=J.toLowerCase();if(q.website)try{let W=new URL(q.website).hostname.toLowerCase();if(Q===W||Q.endsWith("."+W)||W.endsWith("."+Q))return!0}catch{}let X=yq(q.name);if(!X)return!1;return Q.split(".").filter((W)=>W&&!wq.has(W)).some((W)=>{if(W.length>=3&&X.includes(W))return!0;if(X.length>=4&&W.includes(X))return!0;return!1})}function n(q,J){return q.filter((Q)=>a(Q,J))}var O=null,I=null,L=null,A=null,j=null,B=null,F=null,b=null,w=null,Gq=[],k=null,R=null;function t(q){if(k!==null)window.clearTimeout(k),k=null;if(R&&R.parentNode)R.parentNode.removeChild(R),R=null;let J=q.ownerDocument;q.style.outline="2px solid hsl(142 76% 36%)",q.style.outlineOffset="1px",R=J.createElement("div"),R.style.cssText="all: initial; position: fixed; z-index: 2147483647;";let Q=R.attachShadow({mode:"closed"}),X=J.createElement("style");X.textContent=o,Q.appendChild(X);let $=J.createElement("div");$.className="mfa-feedback-badge",$.textContent="✓",Q.appendChild($);let W=q.getBoundingClientRect(),Z=Math.min(Math.max(W.right+8,4),Math.max(4,window.innerWidth-28)),V=W.top+Math.max(0,(W.height-20)/2);R.style.left=Math.round(Z)+"px",R.style.top=Math.round(V)+"px",J.documentElement.appendChild(R),k=window.setTimeout(()=>{if(q.style.outline="",q.style.outlineOffset="",R&&R.parentNode)R.parentNode.removeChild(R);R=null,k=null},1200)}function x(){if(w!==null)window.clearTimeout(w),w=null;for(let q of Gq.splice(0))try{q()}catch{}if(F!==null)window.clearInterval(F),F=null;if(O=null,I=null,A=null,B=null,j&&j.parentNode)j.parentNode.removeChild(j);if(j=null,L&&L.parentNode)L.parentNode.removeChild(L);L=null}function i(){if(!L||!O)return;let q=O.getBoundingClientRect();if(q.width<=0||q.height<=0){x();return}let J=Math.min(Math.max(q.right-c-4,4),Math.max(4,window.innerWidth-c-4)),Q=q.top+Math.max(0,(q.height-c)/2);L.style.left=Math.round(J)+"px",L.style.top=Math.round(Q)+"px"}function Hq(q){if(!j||!L)return;let J=L.getBoundingClientRect(),Q=Math.min(Math.max(q.offsetWidth,220),320),X=q.offsetHeight,$=window.innerWidth,W=window.innerHeight,Z=J.bottom+Dq;if(Z+X>W-8)Z=Math.max(8,J.top-Dq-X);let V=Math.min(Math.max(J.left,8),Math.max(8,$-8-Q));j.style.left=Math.round(V)+"px",j.style.top=Math.round(Z)+"px"}function kq(q,J){let Q=q.ownerDocument;q.innerHTML="";let X=[...J.accounts].sort((V,z)=>Number(a(z,window.location.hostname))-Number(a(V,window.location.hostname)));if(X.length===0){let V=Q.createElement("div");return V.className="mfa-empty",V.textContent=J.strings.noAccounts,q.appendChild(V),()=>{}}let $=new Map;for(let V of X){let z=Q.createElement("div");z.className="mfa-item",z.setAttribute("role","button"),z.tabIndex=0;let Y=Q.createElement("span");Y.className="mfa-item-icon",Y.innerHTML=jq;let K=Q.createElement("div");K.className="mfa-item-main";let P=Q.createElement("div");P.className="mfa-item-name",P.textContent=V.name;let D=Q.createElement("div");D.className="mfa-item-code",D.textContent="······",$.set(V,D),K.appendChild(P),K.appendChild(D);let M=Q.createElement("button");M.type="button",M.className="mfa-item-fill",M.textContent=J.strings.fill,z.appendChild(Y),z.appendChild(K),z.appendChild(M);let _=()=>{let G=J.onFill;x(),v.generateTOTP(V.secret).then((N)=>G(V,N)).catch(()=>{})};z.addEventListener("click",_),M.addEventListener("click",(G)=>{G.stopPropagation(),_()}),z.addEventListener("keydown",(G)=>{if(G.key==="Enter"||G.key===" ")G.preventDefault(),_()}),q.appendChild(z)}let W=Array.from(q.querySelectorAll(".mfa-item"));if(W.length>0)W[0].focus();q.addEventListener("keydown",(V)=>{let z=Array.from(q.querySelectorAll(".mfa-item")),Y=z.indexOf(V.target);if(V.key==="ArrowDown")V.preventDefault(),z[Math.min(z.length-1,Y+1)]?.focus();else if(V.key==="ArrowUp")V.preventDefault(),z[Math.max(0,Y-1)]?.focus();else if(V.key==="Home")V.preventDefault(),z[0]?.focus();else if(V.key==="End")V.preventDefault(),z[z.length-1]?.focus()});let Z=()=>{for(let[V,z]of $)v.generateTOTP(V.secret).then((Y)=>{if(z.isConnected)z.textContent=v.formatCode(Y)}).catch(()=>{})};return Z(),Z}function Iq(){if(!O||!I||j)return;let q=O.ownerDocument;j=q.createElement("div"),j.style.cssText="all: initial; position: fixed; z-index: 2147483647;",B=j.attachShadow({mode:"closed"});let J=q.createElement("style");J.textContent=o,B.appendChild(J);let Q=q.createElement("div");Q.className="mfa-menu",B.appendChild(Q),q.documentElement.appendChild(j),b=kq(Q,I),Hq(Q),F=window.setInterval(()=>{if(b)b()},1000)}function s(){if(F!==null)window.clearInterval(F),F=null;if(b=null,B=null,j&&j.parentNode)j.parentNode.removeChild(j);j=null}function Cq(q,J){x(),O=q,I=J;let Q=q.ownerDocument;L=Q.createElement("div"),L.style.cssText="all: initial; position: fixed; z-index: 2147483646;",A=L.attachShadow({mode:"closed"});let X=Q.createElement("style");X.textContent=o,A.appendChild(X);let $=Q.createElement("button");$.type="button",$.className="mfa-button",$.setAttribute("aria-label",J.strings.fill),$.innerHTML=jq,A.appendChild($),Q.documentElement.appendChild(L),i(),$.addEventListener("mousedown",(K)=>K.preventDefault()),$.addEventListener("click",()=>{let K=I,P=n(K?.accounts??[],window.location.hostname);if(P.length===1){let D=K?.onFill;x(),v.generateTOTP(P[0].secret).then((M)=>D?.(P[0],M)).catch(()=>{});return}if(j)s();else Iq()});let W=(K)=>{if(K.key==="Escape")x()},Z=(K)=>{let P=K.target;if(!P)return;if(P===L||P===j)return;if(A&&A.contains(P))return;if(B&&B.contains(P))return;if(P===O)return;x()},V=()=>{s(),i()},z=()=>{s(),i()},Y=()=>{if(w!==null)window.clearTimeout(w);w=window.setTimeout(()=>{let K=document.activeElement;if(K===L||K===j)return;if(O&&(K===O||O.contains(K)))return;x()},150)};Q.addEventListener("keydown",W,!0),Q.addEventListener("mousedown",Z,!0),window.addEventListener("scroll",V,!0),window.addEventListener("resize",z),Q.addEventListener("focusout",Y,!0),Gq.push(()=>{Q.removeEventListener("keydown",W,!0),Q.removeEventListener("mousedown",Z,!0),window.removeEventListener("scroll",V,!0),window.removeEventListener("resize",z),Q.removeEventListener("focusout",Y,!0)})}var e={"zh-CN":{fill:"填充",noAccounts:"暂无账户，请先在扩展中添加"},"zh-TW":{fill:"填充",noAccounts:"尚無帳戶，請先在擴充功能中新增"},"en-US":{fill:"Fill",noAccounts:"No accounts yet, add one in the extension"},"es-ES":{fill:"Rellenar",noAccounts:"No hay cuentas, añada una en la extensión"},"fr-FR":{fill:"Remplir",noAccounts:"Aucun compte, ajoutez-en un dans l'extension"},"pt-BR":{fill:"Preencher",noAccounts:"Nenhuma conta, adicione uma na extensão"},"de-DE":{fill:"Ausfüllen",noAccounts:"Keine Konten, fügen Sie eines in der Erweiterung hinzu"},"ru-RU":{fill:"Заполнить",noAccounts:"Нет учетных записей, добавьте в расширении"},"ar-SA":{fill:"تعبئة",noAccounts:"لا توجد حسابات، أضف واحدًا في الامتداد"},"ja-JP":{fill:"入力",noAccounts:"アカウントがありません。拡張機能で追加してください"},"ko-KR":{fill:"채우기",noAccounts:"계정이 없습니다. 확장 프로그램에서 추가하세요"},"hi-IN":{fill:"भरें",noAccounts:"कोई खाता नहीं, कृपया एक्सटेंशन में जोड़ें"}};function Tq(){let q=(navigator.language||"en").toLowerCase();if(q.startsWith("zh"))return q.startsWith("zh-tw")||q.startsWith("zh-hk")?"zh-TW":"zh-CN";if(q.startsWith("en"))return"en-US";if(q.startsWith("es"))return"es-ES";if(q.startsWith("fr"))return"fr-FR";if(q.startsWith("pt"))return"pt-BR";if(q.startsWith("de"))return"de-DE";if(q.startsWith("ru"))return"ru-RU";if(q.startsWith("ar"))return"ar-SA";if(q.startsWith("ja"))return"ja-JP";if(q.startsWith("ko"))return"ko-KR";if(q.startsWith("hi"))return"hi-IN";return"en-US"}function Sq(){return new Promise((q)=>{try{chrome.storage.sync.get("language",(J)=>{q(typeof J?.language==="string"?J.language:null)})}catch{q(null)}})}if(!globalThis.__MFA_CS_INITIALIZED__){globalThis.__MFA_CS_INITIALIZED__=!0;let q=[],J=T,Q=e["en-US"],X=null,$=!1,W=0;async function Z(){let z=++W,Y=!1;try{Y=(await chrome.runtime.sendMessage({type:"SITE_ACCESS_CHECK"}))?.allowed===!0}catch{}if(z!==W)return!1;if($=Y,!Y)x(),q=[];return Y}async function V(){let z=await Z();try{if(q=z?await S.getAccounts():[],!$)q=[]}catch{q=[]}try{J=await S.getSettings()}catch{J=T}let Y=await Sq();if(Q=e[Y||Tq()]||e["en-US"],!$||!J.autofillInlineMenu)x()}chrome.storage.onChanged.addListener((z,Y)=>{if(Y==="sync"&&(z.accounts||z.autofillSettings||z.language))V()}),chrome.runtime.onMessage.addListener((z,Y,K)=>{if(!z||typeof z!=="object")return!1;let P=z;if(P.type==="SITE_ACCESS_CHANGED")return $=!1,q=[],x(),V(),!1;if(P.type==="PING"){let D=!1;try{D=!!m()||!!d()}catch{D=!1}return K({ok:!0,hasField:D}),!1}if(P.type==="FILL_CODE"&&typeof P.code==="string"){x();let D=l(P.code);if(D.status==="filled"&&X&&X.isConnected)t(X);if(D.status==="no-field")return window.setTimeout(()=>{try{K(D)}catch{}},300),!0;return K(D),!1}return!1}),document.addEventListener("focusin",async(z)=>{let Y=z.target;if(!(Y instanceof HTMLInputElement))return;if(!J.autofillInlineMenu)return;if(!await Z())return;if(document.activeElement!==Y)return;let K=p(Y),P=E(Y)?f(Y):null;if(!K&&!P)return;X=Y;let D=q.map((_)=>({name:_.name,secret:_.secret,website:_.website})),M=n(D,window.location.hostname);Cq(Y,{accounts:M.length>0?M:D,strings:Q,onFill:async(_,G)=>{if(!await Z())return;if(x(),l(G,Y).status==="filled")t(Y)}})},!0),V()}})();
